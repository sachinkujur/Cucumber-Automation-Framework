package dataProvider;

import managers.FileReaderManager;
import testDataTypes.Customer;

import java.util.List;

public class JsonDataReader {
    private final String customerFilepath = FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath();
    private List<Customer> customerList;

    public JsonDataReader(){
        customerList = getCustomerData();
    }

    public List<Customer> getCustomerData(){
        Gson gson = new Gson();
    }
}
