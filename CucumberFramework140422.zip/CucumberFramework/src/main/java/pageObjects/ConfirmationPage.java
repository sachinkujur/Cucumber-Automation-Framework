package pageObjects;

public class ConfirmationPage {
}
